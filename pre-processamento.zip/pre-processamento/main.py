import cv2
import numpy as np
from pdf2image import convert_from_path
from PIL import Image, ImageEnhance
from PyPDF2 import PdfReader, PdfWriter
import os
from pathlib import Path
import pdfplumber

def aumentar_nitidez(imagem):
    """Aumenta a nitidez da imagem usando kernel de sharpening"""
    kernel = np.array([[-1,-1,-1],
                       [-1, 9,-1],
                       [-1,-1,-1]])
    imagem_nítida = cv2.filter2D(imagem, -1, kernel)
    return imagem_nítida

def detectar_orientacao(imagem):
    """Detecta se a página está de cabeça para baixo usando ORB"""
    orb = cv2.ORB_create()
    keypoints, descriptors = orb.detectAndCompute(imagem, None)
    
    # Se poucos keypoints, assume orientação correta
    if descriptors is None or len(keypoints) < 10:
        return 0
    
    # Rotaciona 180° e compara
    imagem_rotada = cv2.rotate(imagem, cv2.ROTATE_180)
    kp_rot, desc_rot = orb.detectAndCompute(imagem_rotada, None)
    
    if desc_rot is None:
        return 0
    
    # Usa BFMatcher para comparar descritores
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(descriptors, desc_rot)
    
    # Se mais matches com rotação, página está invertida
    return 180 if len(matches) > len(keypoints) * 0.3 else 0

def corrigir_orientacao(imagem):
    """Corrige a orientação da imagem"""
    rotacao = detectar_orientacao(imagem)
    if rotacao == 180:
        imagem = cv2.rotate(imagem, cv2.ROTATE_180)
    return imagem

def processar_pdf(caminho_pdf, dpi=300):
    """Processa PDF: aumenta nitidez e corrige orientação"""
    print(f"Processando: {caminho_pdf}")
    
    imagens_processadas = []
    
    with pdfplumber.open(caminho_pdf) as pdf:
        for idx, pagina in enumerate(pdf.pages):
            print(f"Processando página {idx + 1}/{len(pdf.pages)}...")
            
            # Renderiza página como imagem
            imagem_pil = pagina.to_image(resolution=dpi).original
            
            # Converte para OpenCV (BGR)
            imagem_cv = cv2.cvtColor(np.array(imagem_pil), cv2.COLOR_RGB2BGR)
            
            # Aumenta nitidez
            imagem_nítida = aumentar_nitidez(imagem_cv)
            
            # Corrige orientação
            imagem_corrigida = corrigir_orientacao(imagem_nítida)
            
            # Converte de volta para PIL
            imagem_final = Image.fromarray(cv2.cvtColor(imagem_corrigida, cv2.COLOR_BGR2RGB))
            imagens_processadas.append(imagem_final)
    
    # Salva as imagens como PDF
    nome_saida = Path(caminho_pdf).stem + "_processado.pdf"
    caminho_saida = Path(caminho_pdf).parent / nome_saida
    
    imagens_processadas[0].save(
        str(caminho_saida),
        save_all=True,
        append_images=imagens_processadas[1:],
        optimize=False
    )
    
    print(f"✓ PDF processado salvo em: {caminho_saida}")
    return str(caminho_saida)

if __name__ == "__main__":
    # Exemplo de uso
    pdf_entrada = r"C:\Users\Desktop\pdf_sem_tratamento\nome_arquivo.pdf"
    
    if os.path.exists(pdf_entrada):
        processar_pdf(pdf_entrada, dpi=300)
    else:
        print("Arquivo PDF não encontrado!")